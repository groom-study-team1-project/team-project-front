import React from "react";

function QuestionBoard() {
  return (
    <>
      <div>QuestionBoard</div>
    </>
  );
}

export default QuestionBoard;
