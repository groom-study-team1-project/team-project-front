import React from "react";

function NoticeBoard() {
  return (
    <>
      <div>NoticeBoard</div>
    </>
  );
}

export default NoticeBoard;
