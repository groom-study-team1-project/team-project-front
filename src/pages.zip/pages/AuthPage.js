import React from "react";

function AuthPage() {
  return (
    <>
      <div>AuthPage</div>
    </>
  );
}

export default AuthPage;
