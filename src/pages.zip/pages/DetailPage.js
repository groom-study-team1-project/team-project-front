import React from "react";

function DetailPage() {
  return (
    <>
      <div>DetailPage</div>
    </>
  );
}

export default DetailPage;
