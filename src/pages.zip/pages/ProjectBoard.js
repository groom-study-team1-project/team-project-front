import React from "react";

function ProjectBoard() {
  return (
    <>
      <div>ProjectBoard</div>
    </>
  );
}

export default ProjectBoard;
